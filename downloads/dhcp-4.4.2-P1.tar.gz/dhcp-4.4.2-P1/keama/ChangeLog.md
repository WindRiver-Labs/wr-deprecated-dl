* 3 [doc] fdupont

   New documentation including this file.
   (Gitlab #34)

* 2 [bug] fdupont

   Fixed dhcp4 option 67 wrong name.
   (Gitlab #22)

* 1 [func] fdupont

   Initial revision.

LEGEND
* [bug]   Bug fix.
* [doc]   Update to documentation.
* [func]  New feature.
